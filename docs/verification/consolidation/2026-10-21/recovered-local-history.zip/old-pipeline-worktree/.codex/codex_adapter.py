"""Keep native workers read-only; expose attempt-bound MCP capabilities."""
import json,os,pathlib,re,subprocess,sys,tomllib,queue,threading,time

def validate_caller_config(assignment):
 key,separator,raw=assignment.partition('=')
 expected={
  'developer_instructions':str,
  'model_reasoning_effort':'low',
  'agents.enabled':False,
  'features.apps':False,
  'features.hooks':True,
  'features.shell_tool':False,
  'features.unified_exec':False,
  'web_search':'disabled'
 }
 if not separator or key not in expected:raise ValueError('Caller configuration key is not authorized')
 try:
  parsed=tomllib.loads('value='+raw)
 except tomllib.TOMLDecodeError as exc:raise ValueError('Caller configuration must be one valid TOML value') from exc
 if set(parsed)!={'value'}:raise ValueError('Multiple configuration assignments are forbidden')
 value=parsed['value'];rule=expected[key]
 if rule is str:
  if not isinstance(value,str):raise ValueError('Developer instructions must be a string')
 elif type(value) is not type(rule) or value!=rule:raise ValueError('Caller configuration value conflicts with the confirmed runtime')

def normalize_bound_args(args):
 output=[];index=0
 forbidden={'--dangerously-bypass-approvals-and-sandbox','--yolo','--full-auto','--approve-for-me','--add-dir','--worktree','--ignore-rules','--cd','-C','--profile','-p','--permission-profile','--permissions','--enable','--disable'}
 while index<len(args):
  token=args[index]
  if token.split('=',1)[0] in forbidden or ((token.startswith('-p') or token.startswith('-C')) and not token.startswith('--') and len(token)>2):raise ValueError('Conflicting sandbox/profile option')
  if token.startswith('-a') and not token.startswith('--') and len(token)>2:
   if token[2:]!='never':raise ValueError('Approval policy must remain never')
   index+=1;continue
  if token in {'--sandbox','-s'}:
   if index+1>=len(args):raise ValueError('Missing sandbox value')
   index+=2;continue
  if token.startswith('--sandbox=') or (token.startswith('-s') and not token.startswith('--') and len(token)>2):index+=1;continue
  if token in {'--ask-for-approval','-a'}:
   if index+1>=len(args) or args[index+1]!='never':raise ValueError('Approval policy must remain never')
   index+=2;continue
  if token.startswith('--ask-for-approval='):
   if token.split('=',1)[1]!='never':raise ValueError('Approval policy must remain never')
   index+=1;continue
  value=None;count=1
  if token in {'--config','-c'}:
   if index+1>=len(args):raise ValueError('Missing config value')
   value=args[index+1];count=2
  elif token.startswith('--config='):value=token.split('=',1)[1]
  elif token.startswith('-c') and not token.startswith('--') and len(token)>2:value=token[2:]
  if value is not None:validate_caller_config(value)
  output.extend(args[index:index+count]);index+=count
 at=output.index('exec')+1
 output=[item for item in output if item!='--ignore-user-config']
 at=output.index('exec')+1
 output[at:at]=['--sandbox','read-only']
 return output

def detach_config_overrides(args):
 configs=[];remaining=[];index=0
 while index<len(args):
  token=args[index]
  if token in {'--config','-c'}:configs+=['--config',args[index+1]];index+=2;continue
  if token.startswith('--config='):configs+=['--config',token.split('=',1)[1]];index+=1;continue
  if token.startswith('-c') and not token.startswith('--') and len(token)>2:configs+=['--config',token[2:]];index+=1;continue
  remaining.append(token);index+=1
 return configs,remaining

def attempt_workspace_for_policy(policy_path,policy):
 def matches(folder):
  try:
   plan=json.loads((folder/'plan.json').read_text(encoding='utf-8'))
   task=next(t for t in plan.get('tasks',[]) if t.get('id')==policy.get('task_id'))
   return list(task.get('touches',[]))==list(policy.get('touches',[]))
  except (OSError,ValueError,StopIteration,TypeError):return False
 explicit=policy.get('attempt_workspace')
 if explicit:
  folder=pathlib.Path(explicit).resolve()
  if not matches(folder):raise ValueError('Explicit attempt workspace does not match policy')
  return folder
 candidates=set()
 # The supervisor stores policy.json below its attempt directory. Inspect only
 # that directory and the next two ancestors, not arbitrary project trees.
 for folder in list(pathlib.Path(policy_path).resolve().parents)[:3]:
  if matches(folder):candidates.add(folder)
 for value in policy.get('protected_paths',[]):
  path=pathlib.Path(value).resolve()
  if path.name=='plan.json' and matches(path.parent):candidates.add(path.parent)
 if len(candidates)>1:raise ValueError('Ambiguous attempt workspace')
 return next(iter(candidates)) if candidates else None

def external_server_names(environment,project_root=None,executable=None):
 """Read server names from Codex's effective layered configuration, never credentials."""
 root=pathlib.Path(project_root or pathlib.Path(__file__).resolve().parent.parent).resolve()
 exe=pathlib.Path(executable or root/'.pipeline-preflight/cli/native/package/vendor/x86_64-pc-windows-msvc/bin/codex.exe')
 argv=[str(exe),'--no-daemon','--config','features.apps=false','--config','features.plugins=false','app-server']
 options={'creationflags':subprocess.CREATE_NO_WINDOW} if os.name=='nt' else {}
 process=subprocess.Popen(argv,cwd=root,env=dict(environment),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',**options)
 messages=queue.Queue()
 def read_messages():
  for line in process.stdout:
   try:messages.put(json.loads(line))
   except ValueError:messages.put({'error':'Invalid config response'})
 def drain_errors():
  for _ in process.stderr:pass
 threading.Thread(target=read_messages,daemon=True).start()
 threading.Thread(target=drain_errors,daemon=True).start()
 def request(identifier,method,params):
  process.stdin.write(json.dumps({'jsonrpc':'2.0','id':identifier,'method':method,'params':params})+'\n');process.stdin.flush()
  deadline=time.monotonic()+30
  while time.monotonic()<deadline:
   try:result=messages.get(timeout=1)
   except queue.Empty:
    if process.poll() is not None:raise ValueError('Effective configuration process exited')
    continue
   if result.get('id')==identifier:
    if 'error' in result:raise ValueError('Effective configuration request failed')
    return result['result']
  raise ValueError('Effective configuration request timed out')
 try:
  request(1,'initialize',{'clientInfo':{'name':'ieadpe-policy-discovery','version':'1'},'capabilities':{'experimentalApi':True}})
  result=request(2,'config/read',{'includeLayers':False,'cwd':str(root)})
  return sorted(result.get('config',{}).get('mcp_servers',{}))
 finally:
  if process.poll() is None:process.terminate()
  try:process.wait(timeout=5)
  except subprocess.TimeoutExpired:process.kill();process.wait(timeout=5)


def build_command(args,environment,root,external_servers=()):
 args=list(args)
 exe=root/'.pipeline-preflight/cli/native/package/vendor/x86_64-pc-windows-msvc/bin/codex.exe'
 extra=[]
 if 'exec' in args and environment.get('PIPELINE_ROLE_POLICY'):
  policy_path=pathlib.Path(environment['PIPELINE_ROLE_POLICY']).resolve(strict=True)
  policy=json.loads(policy_path.read_text(encoding='utf-8'))
  if pathlib.Path(policy['workspace_root']).resolve()!=root.resolve():raise SystemExit('Attempt workspace does not match this adapter')
  args=normalize_bound_args(args)
  attempt_workspace=attempt_workspace_for_policy(policy_path,policy)
  capabilities=['context','read_file']
  if policy['role']=='operator':
   capabilities+=['write_file','delete_file']
   if attempt_workspace is not None:capabilities+=['run_check']
  if 'pipeline' in external_servers:raise ValueError('Reserved pipeline server name already exists in user configuration')
  for name in external_servers:
   if not re.fullmatch(r'[A-Za-z0-9_-]+',name):raise ValueError('Cannot safely address external server name with CLI dotted-key syntax')
   extra+=['--config','mcp_servers.'+name+'.enabled=false']
  values={
   'mcp_servers.pipeline.enabled':True,
   'features.apps':False,
   'features.plugins':False,
   'features.multi_agent':False,
   'mcp_servers.pipeline.command':sys.executable,
   'mcp_servers.pipeline.args':['-B','-X','utf8',str(root/'.codex/scoped_tools.py'),str(policy_path)]+([str(attempt_workspace)] if attempt_workspace is not None else []),
   'mcp_servers.pipeline.enabled_tools':capabilities,
   'mcp_servers.pipeline.default_tools_approval_mode':'approve',
   'mcp_servers.pipeline.tool_timeout_sec':1800,
   'mcp_servers.pipeline.required':True,
   'mcp_servers.pipeline.env':{k:environment[k] for k in ['IEADPE_PG_BIN','IEADPE_DATABASE_URL','PYTHONUTF8'] if k in environment}
  }
  for key,value in values.items():
   if isinstance(value,dict):
    for name,item in value.items():extra+=['--config',key+'.'+name+'='+json.dumps(item)]
   else:extra+=['--config',key+'='+json.dumps(value)]
 forwarded,args=detach_config_overrides(args)
 command=[str(exe),'--no-daemon','--config','windows.sandbox="unelevated"',*(['--ask-for-approval','never'] if 'exec' in args and environment.get('PIPELINE_ROLE_POLICY') else []),*extra,*forwarded,*args]
 
 return command

def main():
 root=pathlib.Path(__file__).resolve().parent.parent
 command=build_command(sys.argv[1:],os.environ,root,external_server_names(os.environ,root))
 (root/'.pipeline-preflight/last-invocation.json').write_text(json.dumps({'received':sys.argv[1:],'command':command},indent=2),encoding='utf-8')
 raise SystemExit(subprocess.run(command).returncode)
if __name__=='__main__':main()
