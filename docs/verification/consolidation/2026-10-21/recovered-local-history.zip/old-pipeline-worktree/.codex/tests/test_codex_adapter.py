import unittest,tempfile,pathlib,json,sys,importlib.util,hashlib
sys.dont_write_bytecode=True
sys.path.insert(0,r'C:/Users/Carlos_Neto/.codex/skills/two-model-sdd-pipeline/scripts')
spec=importlib.util.spec_from_file_location('adapter',pathlib.Path('.codex/codex_adapter.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class AdapterTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=pathlib.Path(self.temp.name);p=self.root/'policy.json';p.write_text(json.dumps({'workspace_root':str(self.root),'role':'operator'}));self.env={'PIPELINE_ROLE_POLICY':str(p)}
 def build(self,args):return m.build_command(args,self.env,self.root)
 def assert_readonly(self,c):
  self.assertIn('--sandbox',c);self.assertEqual(c[c.index('--sandbox')+1],'read-only');self.assertNotIn('--sandbox=workspace-write',c)
 def test_existing(self):self.assert_readonly(self.build(['exec','--sandbox','workspace-write']))
 def test_omitted(self):self.assert_readonly(self.build(['exec']))
 def test_equals(self):self.assert_readonly(self.build(['exec','--sandbox=workspace-write']))
 def test_repeated(self):
  c=self.build(['--sandbox','workspace-write','exec','-s','workspace-write']);self.assert_readonly(c);self.assertEqual(c.count('--sandbox'),1);self.assertNotIn('-s',c)
 def test_bypass(self):
  for flag in ['--dangerously-bypass-approvals-and-sandbox','--yolo','--full-auto','--approve-for-me','--add-dir','--worktree','--ignore-rules','--cd','-Cother']:
   with self.assertRaises(ValueError):self.build(['exec',flag])
 def test_mcp_override(self):
  for flag in [['--config','mcp_servers.pipeline.command="evil"'],['-c','mcp_servers."pipeline".args=[]'],['--config=mcp_servers.pipeline.enabled_tools=[]']]:
   with self.assertRaises(ValueError):self.build(['exec',*flag])
 def test_sandbox_override(self):
  with self.assertRaises(ValueError):self.build(['exec','-c','sandbox_mode="danger-full-access"'])
 def test_model_preserved(self):
  c=self.build(['exec','--model','gpt-6.1-sol','-c','model_reasoning_effort="low"']);self.assertIn('gpt-6.1-sol',c);self.assertIn('model_reasoning_effort="low"',c)
 def test_isolated_configuration(self):
  c=self.build(['exec']);self.assertIn('features.plugins=false',c);self.assertIn('features.apps=false',c);self.assertIn('features.multi_agent=false',c)
 def test_no_plugin_or_app_override(self):
  for setting in ['features.plugins=true','features.apps=true','features={plugins=true}']:
   with self.assertRaises(ValueError):self.build(['exec','--config',setting])
 def test_other_servers_disabled(self):
  c=m.build_command(['exec'],self.env,self.root,['unrelated']);self.assertIn('mcp_servers.unrelated.enabled=false',c);self.assertIn('mcp_servers.pipeline.enabled=true',c)
 def test_reserved_server_collision(self):
  with self.assertRaises(ValueError):m.build_command(['exec'],self.env,self.root,['pipeline'])
 def test_config_overrides_share_one_cli_layer(self):
  c=self.build(['exec','--config','model_reasoning_effort="low"']);tail=c[c.index('exec')+1:];self.assertNotIn('--config',tail);self.assertNotIn('-c',tail)
 def test_unsupported_external_server_name(self):
  with self.assertRaises(ValueError):m.build_command(['exec'],self.env,self.root,['unsafe.name'])
 def test_attached_short_options_cannot_widen_policy(self):
  for flag in ['-pother','-aon-request']:
   with self.assertRaises(ValueError):self.build(['exec',flag])
 def test_generated_external_workspace_policy(self):
  import codex_policy
  worktree=self.root/'worktree';worktree.mkdir();ws=self.root/'supervisor';ws.mkdir();prompt=ws/'prompt.md';prompt.write_text('fixture')
  plan=ws/'plan.json';plan.write_text(json.dumps({'tasks':[{'id':1,'touches':['lib/a.dart'],'verification':{'new_test_files':[]}}]}))
  request={'worktree':str(worktree),'evidence_paths':{'prompt_path':str(prompt)},'plan_revision':hashlib.sha256(plan.read_bytes()).hexdigest(),'task_id':1,'role':'operator','dispatch_id':'external-attempt'}
  policy=codex_policy.build_attempt_policy(request,{'capabilities':{'hooks_enabled':True,'hooks_trusted':True}})
  target=ws/'attempts'/'attempt-external'/'policy.json';target.parent.mkdir(parents=True);target.write_text(json.dumps(policy))
  self.assertNotIn(str(plan.resolve()),policy['protected_paths'])
  self.assertEqual(m.attempt_workspace_for_policy(target,policy),ws.resolve())
 def test_noncanonical_and_parent_configuration_rejected(self):
  for setting in ['features\t.\tplugins=true','features\t.\tapps=true','windows={sandbox="elevated"}']:
   with self.assertRaises(ValueError):self.build(['exec','--config',setting])
if __name__=='__main__':unittest.main()
