import unittest,tempfile,pathlib,sys,importlib.util,json
from unittest.mock import patch
from types import SimpleNamespace
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('scoped_tools',pathlib.Path('.codex/scoped_tools.py'));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
class ScopeTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=pathlib.Path(self.temp.name)
  self.policy={'role':'operator','workspace_root':str(self.root),'task_id':1,'attempt_id':'test','touches':['lib/app.dart'],'new_test_files':['test/new_test.dart'],'protected_paths':[],'runner_commands':{},'read_only_commands':[['Get-Content','lib/app.dart']],'supervisor_path_grants':[],'director_approved_existing_changes':[]}
  self.bridge=module.Bridge(self.policy)
 def test_declared_new_file(self):
  self.bridge.write_file('lib/app.dart','hello');self.assertEqual((self.root/'lib/app.dart').read_text(),'hello')
 def test_undeclared_write(self):
  with self.assertRaises(ValueError):self.bridge.write_file('lib/other.dart','bad')
 def test_reviewer_cannot_write(self):
  self.policy['role']='reviewer'
  with self.assertRaises(ValueError):self.bridge.write_file('lib/app.dart','bad')
 def test_traversal(self):
  with self.assertRaises(ValueError):self.bridge.write_file('../outside','bad')
 def test_reference_and_tooling_immutable(self):
  for path in ['reference/base44/a.js','.codex/hooks.json','.git/config','pubspec.yaml']:
   self.policy['touches'].append(path)
   with self.assertRaises(ValueError):self.bridge.write_file(path,'bad')
 def test_selector_injection(self):
  with self.assertRaises(ValueError):self.bridge.run_check('test',['test/a.dart;evil'])
 def test_unknown_mode(self):
  with self.assertRaises(ValueError):self.bridge.run_check('shell',[])
 def test_empty_policy(self):
  with self.assertRaises(ValueError):module.Bridge({})
 def test_unicode_round_trip(self):
  self.bridge.write_file('lib/app.dart','Conversão à igreja');self.assertEqual(self.bridge.read_file('lib/app.dart'),'Conversão à igreja')
 def test_new_test_file(self):
  self.bridge.write_file('test/new_test.dart','test');self.assertTrue((self.root/'test/new_test.dart').is_file())
 def test_read_denied(self):
  with self.assertRaises(ValueError):self.bridge.read_file('private.txt')
 def test_delete_undeclared(self):
  with self.assertRaises(ValueError):self.bridge.delete_file('private.txt')
 def test_format_rejected_without_mutating_undeclared_file(self):
  target=self.root/'other.dart';target.write_text('int f( ){return 1;}')
  with self.assertRaisesRegex(ValueError,'not allowed'):self.bridge.run_check('format',[])
  self.assertEqual(target.read_text(),'int f( ){return 1;}')
 def test_attempt_identity_forwarded_to_runner(self):
  self.policy['protected_paths']=[str(self.root/'plan.json')]
  with patch.object(module.subprocess,'run',return_value=SimpleNamespace(returncode=1,stdout='red',stderr='')) as invoked:
   self.bridge.run_check('red',['test/new_test.dart'])
  self.assertEqual(invoked.call_args.kwargs.get('env',{}).get('PIPELINE_ATTEMPT_ID'),'test')
 def test_explicit_external_attempt_workspace(self):
  external=tempfile.TemporaryDirectory();self.addCleanup(external.cleanup);ws=pathlib.Path(external.name);(ws/'plan.json').write_text(json.dumps({'tasks':[{'id':1}]}))
  self.policy['attempt_workspace']=str(ws)
  with patch.object(module.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout='ok',stderr='')) as invoked:self.bridge.run_check('test',[])
  self.assertEqual(invoked.call_args.args[0][2],str(ws.resolve()))
 def test_declared_external_review_context_can_be_read(self):
  external=tempfile.TemporaryDirectory();self.addCleanup(external.cleanup);target=pathlib.Path(external.name)/'review.md';target.write_text('review context')
  self.policy['role']='reviewer';self.policy['read_only_commands']=[['Get-Content',str(target)]]
  self.assertEqual(self.bridge.read_file(str(target)),'review context')
if __name__=='__main__':unittest.main()
