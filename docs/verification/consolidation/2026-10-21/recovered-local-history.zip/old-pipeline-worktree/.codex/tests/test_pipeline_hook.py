import unittest,tempfile,pathlib,sys,importlib.util,shlex
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('hook',pathlib.Path('.codex/pipeline_hook.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class HookTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=pathlib.Path(self.temp.name);self.ws=self.root/'workspace';self.ws.mkdir()
  self.policy={'role':'operator','workspace_root':str(self.root),'task_id':1,'attempt_id':'test','touches':[],'new_test_files':[],'protected_paths':[str(self.ws/'plan.json')],'runner_commands':{},'read_only_commands':[],'supervisor_path_grants':[],'director_approved_existing_changes':[]}
 def event(self,mode):return {'hook_event_name':'PreToolUse','tool_name':'Bash','tool_input':{'command':shlex.join(['bash',str(m.SCRIPTS/'scoped-run'),str(self.ws),'1',mode])}}
 def test_worker_format_denied(self):self.assertEqual(m.decision(self.event('format'),self.policy)['hookSpecificOutput']['permissionDecision'],'deny')
 def test_worker_red_allowed(self):self.assertEqual(m.decision(self.event('red'),self.policy)['hookSpecificOutput']['permissionDecision'],'allow')
if __name__=='__main__':unittest.main()
