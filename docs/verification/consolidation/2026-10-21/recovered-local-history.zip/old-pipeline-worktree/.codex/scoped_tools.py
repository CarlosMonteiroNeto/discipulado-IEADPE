"""Task-bound MCP capabilities for workers whose native tools stay read-only."""
import json,os,pathlib,re,subprocess,sys,tempfile
sys.dont_write_bytecode=True
if hasattr(sys.stdin,"reconfigure"):sys.stdin.reconfigure(encoding="utf-8")
if hasattr(sys.stdout,"reconfigure"):sys.stdout.reconfigure(encoding="utf-8",newline="\n")
SCRIPTS=pathlib.Path(r'C:/Users/Carlos_Neto/.codex/skills/two-model-sdd-pipeline/scripts')
sys.path.insert(0,str(SCRIPTS))
import codex_policy

class Bridge:
 def __init__(self,policy):
  self.policy=policy
  self.root=codex_policy._policy_root(policy)
 def relative(self,value):
  if not isinstance(value,str) or not value or '\x00' in value:raise ValueError('Invalid path')
  return codex_policy._relative(self.policy,value)
 def authorize_write(self,value):
  if self.policy['role']!='operator':raise ValueError('Role cannot edit')
  rel=self.relative(value);low=rel.casefold();name=pathlib.PurePosixPath(low).name
  if low.startswith(('reference/','.codex/','.git/','.superpowers/','.pipeline-preflight/')) or low in {'.git','.codex'} or name in {'pubspec.yaml','pubspec.lock','package.json','package-lock.json','runtime.json','plan.json','ledger.jsonl'} or codex_policy._is_protected(rel,self.policy):raise ValueError('Protected path')
  allowed=[*self.policy['touches'],*self.policy['new_test_files']]
  if not (any(self.relative(p).casefold()==low for p in allowed) or codex_policy._grant(rel,self.policy,'supervisor','supervisor_path_grants') or codex_policy._grant(rel,self.policy,'director','director_approved_existing_changes',approved=True)):raise ValueError('Path is outside the declared task scope')
  return self.root/pathlib.PurePosixPath(rel)
 def write_file(self,path,content):
  if not isinstance(content,str) or len(content.encode('utf-8'))>2_000_000:raise ValueError('Invalid content')
  target=self.authorize_write(path);target.parent.mkdir(parents=True,exist_ok=True)
  # Re-resolve after directory creation to reject symlink or junction escape.
  target=self.authorize_write(path)
  with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',newline='',dir=target.parent,delete=False) as stream:
   stream.write(content);temporary=pathlib.Path(stream.name)
  try:os.replace(temporary,target)
  finally:
   if temporary.exists():temporary.unlink()
  return {'path':path,'bytes':len(content.encode('utf-8'))}
 def delete_file(self,path):
  target=self.authorize_write(path)
  if not target.is_file():raise ValueError('File does not exist')
  target.unlink();return {'deleted':path}
 def read_file(self,path):
  if not isinstance(path,str) or not path or '\x00' in path:raise ValueError('Invalid path')
  target=(self.root/pathlib.Path(path)).resolve()
  declared=False
  for argv in self.policy['read_only_commands']:
   if len(argv)==2 and argv[0]=='Get-Content':
    candidate=(self.root/pathlib.Path(argv[1])).resolve()
    declared=declared or candidate==target
  try:
   rel=self.relative(path)
   allowed=declared or rel.startswith(('reference/base44/','lib/','test/','integration_test/','supabase/','scripts/','docs/')) or rel in {'README.md','pubspec.yaml','pubspec.lock','analysis_options.yaml'}
  except ValueError:allowed=declared
  name=target.name.casefold()
  if name.startswith('.env') or name.endswith(('.pem','.key')) or name in {'auth.json','credentials.json','service-account.json'}:allowed=False
  if not allowed:raise ValueError('Read is outside the declared task context')
  if target.stat().st_size>2_000_000:raise ValueError('File exceeds read limit')
  return target.read_text(encoding='utf-8')
 def attempt_workspace(self):
  explicit=self.policy.get('attempt_workspace')
  if explicit:
   folder=pathlib.Path(explicit).resolve(strict=True)
   plan=json.loads((folder/'plan.json').read_text(encoding='utf-8'))
   if not any(t.get('id')==self.policy['task_id'] for t in plan.get('tasks',[])):raise ValueError('Attempt task is absent from workspace')
   return folder
  workspaces=[pathlib.Path(p).resolve().parent for p in self.policy['protected_paths'] if pathlib.Path(p).name=='plan.json']
  if len(workspaces)!=1:raise ValueError('Missing unambiguous pipeline workspace')
  return workspaces[0]
 def run_check(self,mode,selectors):
  if self.policy['role']!='operator' or mode not in {'red','test','analyze'}:raise ValueError('Check is not allowed')
  if not isinstance(selectors,list) or any(not isinstance(v,str) or not re.fullmatch(r'[A-Za-z0-9_./-]+\.dart',v) or pathlib.PurePosixPath(v).is_absolute() or '..' in pathlib.PurePosixPath(v).parts for v in selectors):raise ValueError('Invalid selectors')
  if mode in {'format','analyze'} and selectors:raise ValueError('Mode has no selectors')
  workspace=self.attempt_workspace()
  argv=[r'C:/Program Files/Git/bin/bash.exe',str(SCRIPTS/'scoped-run'),str(workspace),str(self.policy['task_id']),mode,*selectors]
  runner_env=dict(os.environ,PIPELINE_ATTEMPT_ID=str(self.policy['attempt_id']),PIPELINE_PROJECT_ROOT=str(self.root),PYTHONUTF8='1')
  result=subprocess.run(argv,cwd=self.root,env=runner_env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=1800)
  return {'exit_code':result.returncode,'output':(result.stdout+result.stderr)[-48000:]}
 def tool_names(self):
  names={'context','read_file'}
  if self.policy['role']=='operator':
   names.update({'write_file','delete_file'})
   try:self.attempt_workspace();names.add('run_check')
   except (OSError,ValueError):pass
  return names
 def context(self):
  return {'role':self.policy['role'],'task_id':self.policy['task_id'],'touches':self.policy['touches'],'new_test_files':self.policy['new_test_files'],'read_paths':[a[1] for a in self.policy['read_only_commands'] if len(a)==2 and a[0]=='Get-Content'],'instructions':('Native tools are read-only. Use scoped tools for task files and red/test/analyze. Script CEO owns formatting. Checks invoke installed scoped-run and scripts/cmd; raw shell strings are never accepted.' if self.policy['role']=='operator' else 'This role is read-only. Only context and read_file are available. Do not run checks or edit files; inspect the supplied review package.')}

TOOLS=[
 {'name':'context','description':'Get the current task file scope and instructions. Native tools are read-only; use this server for edits and checks.','inputSchema':{'type':'object','properties':{},'additionalProperties':False}},
 {'name':'read_file','description':'Read a declared task file or immutable captured Base44 source.','inputSchema':{'type':'object','properties':{'path':{'type':'string'}},'required':['path'],'additionalProperties':False}},
 {'name':'write_file','description':'Write the complete UTF-8 contents of a file explicitly declared by the current task. Use this instead of native apply_patch, which is read-only.','inputSchema':{'type':'object','properties':{'path':{'type':'string'},'content':{'type':'string'}},'required':['path','content'],'additionalProperties':False}},
 {'name':'delete_file','description':'Delete one file explicitly declared by the current task. Directories and protected files are rejected.','inputSchema':{'type':'object','properties':{'path':{'type':'string'}},'required':['path'],'additionalProperties':False}},
 {'name':'run_check','description':'Run the installed pipeline scoped-run command using structured red/test/analyze mode and Dart test paths. Use this instead of shell test commands. RED evidence is saved by the installed runner.','inputSchema':{'type':'object','properties':{'mode':{'type':'string','enum':['red','test','analyze']},'selectors':{'type':'array','items':{'type':'string'},'default':[]}},'required':['mode'],'additionalProperties':False}}
]
def main():
 if len(sys.argv)>3:raise ValueError('Unexpected startup arguments')
 policy_path=pathlib.Path(sys.argv[1] if len(sys.argv)>=2 else os.environ['PIPELINE_ROLE_POLICY']).resolve(strict=True)
 policy=json.loads(policy_path.read_text(encoding='utf-8'))
 if len(sys.argv)==3:policy['attempt_workspace']=str(pathlib.Path(sys.argv[2]).resolve(strict=True))
 bridge=Bridge(policy)
 os.environ['PIPELINE_ROLE_POLICY']=str(policy_path)
 for line in sys.stdin:
  request={}
  try:
   request=json.loads(line);method=request.get('method');identifier=request.get('id')
   if identifier is None:continue
   if method=='initialize':result={'protocolVersion':request.get('params',{}).get('protocolVersion','2024-11-05'),'capabilities':{'tools':{}},'serverInfo':{'name':'ieadpe-task-capabilities','version':'1.0.0'}}
   elif method=='tools/list':result={'tools':[t for t in TOOLS if t['name'] in bridge.tool_names()]}
   elif method=='ping':result={}
   elif method=='tools/call':
    params=request['params'];name=params['name'];args=params.get('arguments',{})
    if name not in bridge.tool_names():raise ValueError('Unknown capability')
    if name=='run_check':args.setdefault('selectors',[])
    try:value=getattr(bridge,name)(**args);result={'content':[{'type':'text','text':value if isinstance(value,str) else json.dumps(value)}]}
    except Exception as exc:result={'isError':True,'content':[{'type':'text','text':str(exc)}]}
   else:
    print(json.dumps({'jsonrpc':'2.0','id':identifier,'error':{'code':-32601,'message':'Unknown method'}}),flush=True);continue
   print(json.dumps({'jsonrpc':'2.0','id':identifier,'result':result}),flush=True)
  except Exception as exc:
   print(json.dumps({'jsonrpc':'2.0','id':request.get('id') if isinstance(request,dict) else None,'error':{'code':-32602,'message':str(exc)}}),flush=True)
if __name__=='__main__':main()
