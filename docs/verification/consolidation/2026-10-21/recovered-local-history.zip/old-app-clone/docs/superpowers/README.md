# Active conversion documents

Accepted direction: Flutter web/Android + Supabase Free + Google OAuth, including shared photos. UI is pt-BR; communication and artifacts are English.

- [Design](specs/2026-10-14-ieadpe-flutter-supabase-free-design.md)
- [19-task implementation plan](plans/2026-10-14-ieadpe-flutter-supabase-free-sdd.md)
- [SDD runbook](plans/ieadpe-supabase-sdd-runbook.md)
- [Unified app integration roadmap](plans/2026-10-16-unified-discipulado-integration-roadmap.md) — builds on the completed 19-task implementation
- Post-implementation integration planning: [convert skill alignment](specs/2026-10-16-convert-skill-alignment-design.md), [IEADPE Supabase port](specs/2026-10-16-ministry-supabase-port-design.md), [unified journey](specs/2026-10-16-unified-journey-design.md), and [quality/release](specs/2026-10-16-unified-quality-release-design.md). Each spec has a matching JSON plan in `plans/`.
- [Model configuration example](plans/ieadpe-sdd-config.toml.example) — documentation only, not activated

Older Firebase, Spark and generic backend drafts are historical. The 19-task Flutter implementation is complete in the managed worktree on `implementation/supabase-free` at `642047f`; this primary checkout has not been updated to that branch. Production deployment and personal-record migration remain separate release work. The unified integration roadmap and IEADPE engineering-skill coverage govern subsequent planning.
